from .multi_label_image_classification import MultiLabelImageClassification

__all__ = ['MultiLabelImageClassification']
